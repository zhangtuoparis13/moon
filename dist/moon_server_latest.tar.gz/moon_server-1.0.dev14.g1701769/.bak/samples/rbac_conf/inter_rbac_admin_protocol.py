def rbac_admin_requesting_vent_create(vent, subjects_list):
    pass


def rbac_admin_requested_vent_create(vent, objects_list):
    pass
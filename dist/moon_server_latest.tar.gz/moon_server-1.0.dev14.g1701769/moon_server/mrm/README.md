MRM: Model-based Reference Monitor

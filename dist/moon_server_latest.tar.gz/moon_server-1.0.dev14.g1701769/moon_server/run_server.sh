#!/bin/bash

unset http_proxy

# python -m moon.moon_server --run runserver 0.0.0.0:8080
python -m moon.moon_server --run runserver 0.0.0.0:8888
/**
 * @author arnaud marhin<arnaud.marhin@orange.com>
 */

(function() {

	'use strict';
					
	angular
		.module('moon')
			.controller('InterExtensionListController', InterExtensionListController);
	
	function InterExtensionListController() {
	
		
	
	};
	
})();